package me.jrl.demo38;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class LoginActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE ="" ;
    private Button mBtnlogin;
    private EditText name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mBtnlogin=findViewById(R.id.loginLog);
        name=findViewById(R.id.EditTextuid);
        mBtnlogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                //Intent是一种运行时绑定（run-time binding）机制，它能在程序运行过程中连接两个不同的组件。
                //page1为先前已添加的类，并已在AndroidManifest.xml内添加活动事件(<activity android:name="page1"></activity>),在存放资源代码的文件夹下下，
                Intent i = new Intent(LoginActivity.this , MainActivity.class);
                ////启动
                String message = name.getText().toString();
                i.putExtra(EXTRA_MESSAGE, message);
                startActivity(i);
            }
        });
    }
}