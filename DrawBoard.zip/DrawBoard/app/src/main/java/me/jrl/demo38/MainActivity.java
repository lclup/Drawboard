package me.jrl.demo38;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private DrawingBoard mDrawingBoard;//画板
    //private Slider mSlider;//滑动条
    //代表颜色选项
    private ImageView Black;
    private ImageView Accent;
    private ImageView Primary;
    private ImageView Red;
    //对画板的操作
    private ImageView mPaint;
    private ImageView mEraser;
    private ImageView mClean;
    private ImageView mLast;
    private ImageView mNext;
    private TextView show;
    //记录画笔大小
    private float size;

    //获取像素点
    private int dip2x(float depValue){
        final float density = getResources().getDisplayMetrics().density;
        return (int)(depValue*density+0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//activity_main.xml
        show = findViewById(R.id.textView);
        initView();//绑定
        initEvent();//匹配监听事件
        Intent i = getIntent();
        String message =i.getStringExtra(LoginActivity.EXTRA_MESSAGE);
        show.setText(message);


        //addSliderListener();//滑动条监听
    }

    @Override
    protected void onResume() {
        super.onResume();
        //默认画笔大小
       size  = dip2x(10);
    }

    private void initView(){//对象 找控件
        mDrawingBoard = findViewById(R.id.draw_board);
       // mSlider = findViewById(R.id.slider);
        Black = findViewById(R.id.iv_one);
        Accent = findViewById(R.id.iv_two);
        Primary = findViewById(R.id.iv_three);
        Red = findViewById(R.id.iv_four);
        mPaint = findViewById(R.id.iv_paint);
        mEraser = findViewById(R.id.iv_eraser);
        mClean = findViewById(R.id.iv_clean);
        mLast = findViewById(R.id.iv_last);
        mNext = findViewById(R.id.iv_save);
    }
    //实现滑动小圆点改变画笔线条粗细大小
//    private void addSliderListener(){
//        mSlider.addListener(new Slider.OnSliderChangedListener() {
//            @Override
//            public void positionChanged(float p) {
//                if (size > 0) {
//                    mDrawingBoard.setmPaintSize((int) (p * size * 2));
//                }
//            }
//        });
//    }

    private void initEvent(){

        Black.setOnClickListener(this);
        Accent.setOnClickListener(this);
        Primary.setOnClickListener(this);
        Red.setOnClickListener(this);
        //设置默认画笔背景为蓝色
        mPaint.getBackground().setLevel(1);
        mPaint.getDrawable().setLevel(1);
        mPaint.setOnClickListener(this);
        mEraser.setOnClickListener(this);
        mClean.setOnClickListener(this);
        mLast.setOnClickListener(this);
        mNext.setOnClickListener(this);

    }

    //设置画板清空对话框
    private void alertDialogClean(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("确定要请空画板吗？");
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                mDrawingBoard.clean();
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        final  AlertDialog dialog = builder.show();
        dialog.show();
    }
//保存图片

    /** 保存方法 */
    public void saveBitmap(Bitmap bitmap,String foldername,String picName) {
        File folder = new File(foldername );
        if (!folder.exists()) {
            folder.mkdir();
        }
        SaveFileThread saveFileThread;
        saveFileThread = new SaveFileThread( foldername+"/"+picName,bitmap);
        saveFileThread.run();
    }

    private class SaveFileThread implements Runnable{
        private String mPath;
        private Bitmap mBitmap;
        public SaveFileThread(String path,Bitmap bitmap){
            this.mPath=path;
            this.mBitmap=bitmap;
        }
        @Override
        public void run() {
            File file = new File(mPath);
            try {
                FileOutputStream out = new FileOutputStream(file);
                mBitmap.compress(Bitmap.CompressFormat.PNG, 80, out);
                out.flush();
                out.close();
                Log.e("MainActivity", "已经保存");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.iv_one:
                mDrawingBoard.setmPaintColor(Color.BLACK);
                break;
            case R.id.iv_two:
                mDrawingBoard.setmPaintColor(Color.parseColor("#D81B60"));

                break;
            case R.id.iv_three:
                mDrawingBoard.setmPaintColor(Color.parseColor("#008577"));
                break;
            case R.id.iv_four:
                mDrawingBoard.setmPaintColor(Color.RED);
                break;
            case R.id.iv_paint:
                if (mDrawingBoard.getMode() != DrawMode.PaintMode) {
                    mDrawingBoard.setMode(DrawMode.PaintMode);
                }
                mPaint.getDrawable().setLevel(1);
                mPaint.getBackground().setLevel(1);
                mEraser.getDrawable().setLevel(0);
                mEraser.getBackground().setLevel(0);

                break;
            case R.id.iv_eraser:
                if (mDrawingBoard.getMode() != DrawMode.EraserMode) {
                    mDrawingBoard.setMode(DrawMode.EraserMode);
                }
                mPaint.getDrawable().setLevel(0);
                mPaint.getBackground().setLevel(0);
                mEraser.getDrawable().setLevel(1);
                mEraser.getBackground().setLevel(1);
                break;
            case R.id.iv_clean:
                alertDialogClean();
                break;
                //保存文件
            case R.id.iv_save :
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
                String picName = dateFormat.format(new Date()) + ".png";
                String foldername="acct/yyds";
               saveBitmap( mDrawingBoard.mBufferBitmap, foldername, picName);
//                String path=foldername+'/'+picName;
//                if(!TextUtils.isEmpty(path)) {
//                    File f = new File(path);
//                    FileOutputStream out = null;
//                    try {
//                        out = new FileOutputStream(f);
//                        mDrawingBoard.mBufferBitmap.compress(Bitmap.CompressFormat.JPEG,90,out);
//                        out.flush();
//                        out.close();
//                    }
//
//                    }
//                    } catch (FileNotFoundException e) {
//                        e.printStackTrace();
//                    }
//                    //以90质量保存到输出到文件输出流
//                }

                break;
            case R.id.iv_last://撤销
                mDrawingBoard.nextStep();
                break;
        }
    }
}
