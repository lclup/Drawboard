package me.jrl.demo38;

public enum DrawMode {
    //画笔模式
    PaintMode,
    //橡皮擦
    EraserMode,
}
